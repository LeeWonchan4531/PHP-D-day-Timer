<!DOCTYPE html>
<html lang="ko">

<head>
  <title>Global</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=0.3">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Wonchan's Portofolio">
  <meta name="author" content="Bucky Maler, wonchan">
  <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>
  <div class="perspective effect-rotate-left">
    <div class="container">
      <div class="outer-nav--return"></div>
      <div id="viewport" class="l-viewport">
        <div class="l-wrapper">
          <header class="header">
            <a class="header--logo" href="index.php">
              <p>LeeWonchan</p>
            </a>
            <div class="header--nav-toggle">
              <span></span>
            </div>
          </header>
          <nav class="l-side-nav">
            <ul class="side-nav">
              <li class="is-active"><span>Home</span></li>
              <li><span>Skills</span></li>
              <li><span>About</span></li>
              <li><span>Contact</span></li>
              <li><span>Server Status</span></li>
            </ul>
          </nav>
          <ul class="l-main-content main-content">
            <li class="l-section section section--is-active">
              <div class="intro">
                <div class="intro--banner">
                  <h2 style="font-size: 45px;"><br>I'm going to <br><span class="dev-ops"></span></h2>
                  <img src="assets/img/introduction-visual.png" alt="Welcome" height="325px">
                </div>
              </div>
            </li>
            <li class="l-section section">
              <div class="work">
                <h2>I can handle things like this</h2>
                <div class="work--lockup">
                  <ul class="slider">
                    <li class="slider--item slider--item-left">
                      <a href="#0">
                        <div class="slider--item-image">
                          <img src="assets/img/work-victory.jpg" alt="Victory">
                        </div>
                        <p class="slider--item-title">BACKEND(PHP, MARIADB ..)</p>
                        <p class="slider--item-description">PHP, MARIADB를 이용하여 실제 학교 시간표, 학사일정 등 확인 웹사이트를 운영 중 입니다.<br>
                          PHP, MARIADB 말고 입학하여 더 많은 벡엔드 언어를 배우고 싶습니다. </p>
                      </a>
                    </li>
                    <li class="slider--item slider--item-center">
                      <a href="#0">
                        <div class="slider--item-image">
                          <img src="assets/img/work-metiew-smith.jpg" alt="Metiew and Smith">
                        </div>
                        <p class="slider--item-title">LINUX(PROXMOX, ROCKY LINUX, UBUNTU)</p>
                        <p class="slider--item-description">리눅스 서버를 이용하여 실제 학교 시간표, 학사일정 등 확인 웹사이트를 운영 중 입니다.</p>
                      </a>
                    </li>
                    <li class="slider--item slider--item-right">
                      <a href="#0">
                        <div class="slider--item-image">
                          <img src="assets/img/work-alex-nowak.jpg" alt="Alex Nowak">
                        </div>
                        <p class="slider--item-title">FRONTEND(HTML, CSS, JAVASCIRPT)</p>
                        <p class="slider--item-description">HTML, CSS, JAVASCIRPT를 이용하여 실제 학교 시간표, 학사일정 등 확인 웹사이트를 운영 중
                          입니다.<br> HTML, CSS, JAVASCIRPT 말고 입학하여 React나 Vue.js 등 을 배우고 싶습니다.</p>
                      </a>
                    </li>
                  </ul>
                  <div class="slider--prev">
                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
                      xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 118"
                      style="enable-background:new 0 0 150 118;" xml:space="preserve">
                      <g transform="translate(0.000000,118.000000) scale(0.100000,-0.100000)">
                        <path d="M561,1169C525,1155,10,640,3,612c-3-13,1-36,8-52c8-15,134-145,281-289C527,41,562,10,590,10c22,0,41,9,61,29
                    c55,55,49,64-163,278L296,510h575c564,0,576,0,597,20c46,43,37,109-18,137c-19,10-159,13-590,13l-565,1l182,180
                    c101,99,187,188,193,199c16,30,12,57-12,84C631,1174,595,1183,561,1169z" />
                      </g>
                    </svg>
                  </div>
                  <div class="slider--next">
                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
                      xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 150 118"
                      style="enable-background:new 0 0 150 118;" xml:space="preserve">
                      <g transform="translate(0.000000,118.000000) scale(0.100000,-0.100000)">
                        <path
                          d="M870,1167c-34-17-55-57-46-90c3-15,81-100,194-211l187-185l-565-1c-431,0-571-3-590-13c-55-28-64-94-18-137c21-20,33-20,597-20h575l-192-193C800,103,794,94,849,39c20-20,39-29,61-29c28,0,63,30,298,262c147,144,272,271,279,282c30,51,23,60-219,304C947,1180,926,1196,870,1167z" />
                      </g>
                    </svg>
                  </div>
                </div>
              </div>
            </li>
            <li class="l-section section">
              <div class="about">
                <div class="about--banner">
                  <h3 style="font-size: 30px;">초등학교때부터 유난히 IT 분야를 좋아하였고, <br>그 중에서도 하드웨어에 큰 관심이 있었습니다.<br> 서버라는 것을 접하게
                    되며 프로그래밍 보다 더욱 흥미를 느끼면서, <br>중학교에 진학 후
                    리눅스 서버, 네트워크 등 에 관한 전반적인 기술을 습득, 독학하였습니다. <br> 현재는 클라우드 분야를 시작하며 클라우드 관련
                    기술과 실제로 서버를 구축하고 서비스를 운영하며 DevOps에 관한 기술을 습득 중인 학생입니다!</h3>
                  <b style="font-size: 20px; text-decoration: underline;">실제 운영 중인 서비스와 창의력을 이용하여 만들었던 프로젝트들👇</b>

                </div>
                <div class="about--options">
                  <a href="https://swon.wonchan.net/">
                    <h3 style="font-size: 13px;">학사정보제공 웹사이트</h3>
                  </a>
                  <a href="https://천지인.kr/">
                    <h3>학원 웹사이트</h3>
                  </a>
                  <a href="#0">
                    <h3 style="font-size: 11px;">가상화를 이용한 홈 서버 구축</h3>
                  </a>
                </div>
              </div>
            </li>
            <li class="l-section section">
              <div class="contact">
                <div class="contact--lockup">
                  <div class="modal">
                    <div class="modal--information">
                      <p>이름:이원찬</p>
                      <a href="mailto:wonchan@wonchan.net">Email: wonchan@wonchan.net</a>
					  <a href="https://github.com/LeeWonchan4531" target="_blank">Github: https://github.com/LeeWonchan4531</a>
                    </div>
                    <ul class="modal--options">
                      <li><a href="mailto:wonchan@wonchan.net">Contact Me!</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </li>
            <li class="l-section section">
              <div class="hire">
                
                <!-- checkout formspree.io for easy form setup -->
                <form class="work-request">
    <h2>운영 중인 서버 상태</h2>
                <svg width="770" height="690" xmlns="http://www.w3.org/2000/svg">
							<g>
							  <ellipse fill="<?php
					  
											  //Main Server
											  $host1 = '192.168.219.101';
											  if ($socket1 = @fsockopen($host1, 8006, $errno1, $errstr1, 30)) {
												echo '#06c712';
												fclose($socket1);
											  } else {
												echo '#730a10';
											  }
					  
											  ?>" stroke="#000" cx="137.20581" cy="252.70218" id="svg_1" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="95.1161" y="258.70218" id="svg_3" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Main Server</text>
							  <line stroke="#fff" fill="none" x1="137.45581" y1="302.7023" x2="136.95581" y2="379.70218" id="svg_4" />
							  <ellipse fill="     <?php
					  
												  //Proxy Server
												  $host2 = '192.168.219.102';
												  if ($socket2 = @fsockopen($host2, 81)) {
													echo '#06c712';
													fclose($socket2);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="137.20581" cy="433.36885" id="svg_2" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="110.53912" y="437.36885" id="svg_7" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="95.10725" y="447.36885" id="svg_8" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <text fill="#000000" stroke="#000" x="101.53125" y="269.70218" id="svg_9" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Proxmox vm Server</text>
							  <path stroke="#fff" id="svg_11" d="m118.9353,479.96841l0.27041,33.70776" fill="none" />
							  <path transform="rotate(49 98.9488 530.319)" id="svg_13" d="m99.04852,503.75049l-0.19992,53.13709" opacity="undefined" stroke="#fff" fill="none" />
							  <line stroke="#fff" fill="none" x1="78.73217" y1="546.95073" x2="79.31816" y2="584.89973" id="svg_14" />
							  <ellipse fill="#fff" stroke="#000" cx="79.62112" cy="641.21586" id="svg_17" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="52.95442" y="645.21586" id="svg_18" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="37.52255" y="655.21586" id="svg_19" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse ry="2" rx="2" id="svg_23" cy="586.47831" cx="79.03087" stroke="#fff" fill="none" />
							  <path stroke="#fff" id="svg_41" d="m124.21015,481.61133l0.26763,53.40958" fill="none" />
							  <path stroke="#fff" id="svg_42" d="m129.57141,482.59686l-0.06212,44.25329" fill="none" />
							  <path stroke="#000" id="svg_43" d="m134.87512,517.5278" fill="none" />
							  <path stroke="#fff" id="svg_44" d="m139.63932,483.47309l-0.06424,35.9431" fill="none" />
							  <path stroke="#fff" id="svg_45" d="m144.89647,482.92546l-0.06372,21.00223" fill="none" />
							  <path stroke="#fff" id="svg_46" d="m150.26258,482.0492l-0.06212,11.31911" fill="none" />
							  <ellipse fill="     <?php
					  
												  //Portofolio
												  $host3 = '192.168.219.106';
												  if ($socket3 = @fsockopen($host3, 80)) {
													echo '#06c712';
													fclose($socket3);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="79.62112" cy="641.21586" id="svg_48" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="52.95442" y="645.21586" id="svg_49" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-105</text>
							  <text fill="#000000" stroke="#000" x="40.52255" y="656.21586" id="svg_50" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Portofolio Web Server</text>
							  <text fill="#000000" stroke="#000" x="162.04533" y="644.23009" id="svg_52" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="146.61346" y="654.23009" id="svg_53" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="162.04533" y="644.35541" id="svg_55" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-101</text>
							  <text fill="#000000" stroke="#000" x="146.61346" y="654.23009" id="svg_56" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Ubuntu Cheonjiin Server</text>
							  <line stroke="#fff" fill="none" x1="187.1294" y1="564.74542" x2="187.21419" y2="584.76387" id="svg_57" />
							  <ellipse ry="2" rx="2" id="svg_58" cy="586.76387" cx="187.42812" stroke="#fff" fill="none" />
							  <path id="svg_60" d="m186.95383,565.22137l-62.28142,-30.20085" opacity="undefined" stroke="#fff" fill="none" />
							  <ellipse fill="     <?php
					  
												  //Firewall
												  $host4 = '125.183.199.89';
												  if ($socket4 = @fsockopen($host4, 80)) {
													echo '#06c712';
													fclose($socket4);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="137.20581" cy="70.47995" id="svg_61" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="111.36531" y="72.35619" id="svg_62" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">FireWall</text>
							  <line stroke="#fff" fill="none" x1="137.45581" y1="120.48008" x2="136.95581" y2="197.47995" id="svg_63" />
							  <text fill="#000000" stroke="#000" x="112.8328" y="85.41807" id="svg_64" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">LG U+ Router</text>
							  <ellipse opacity="0.95" ry="2" rx="2" id="svg_65" cy="381.09171" cx="136.85661" stroke="#fff" fill="none" />
							  <ellipse opacity="0.95" ry="2" rx="2" id="svg_66" cy="199.66928" cx="136.85661" stroke="#fff" fill="none" />
							  <path stroke="#fff" id="svg_67" d="m299.26872,570.97056l-170.1473,-44.20667" opacity="undefined" fill="none" />
							  <text fill="#000000" stroke="#000" x="162.04533" y="644.23009" id="svg_69" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="146.61346" y="654.23009" id="svg_70" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="     <?php
					  
												  //천지인
												  $host5 = '192.168.219.103';
												  if ($socket5 = @fsockopen($host5, 80)) {
													echo '#06c712';
													fclose($socket5);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="188.71203" cy="641.71509" id="svg_71" rx="50" ry="50" />
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="162.04533" y="644.35541" id="svg_72" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-101</text>
							  <text fill="#000000" stroke="#000" x="144.61346" y="654.23009" id="svg_73" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Ubuntu Cheonjiin Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="297.11377" cy="639.69056" id="svg_74" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="270.44707" y="643.69056" id="svg_75" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="255.0152" y="653.69056" id="svg_76" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="297.11377" cy="639.69056" id="svg_77" rx="50" ry="50" />
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="270.44707" y="643.81588" id="svg_78" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-101</text>
							  <text fill="#000000" stroke="#000" x="255.0152" y="653.69056" id="svg_79" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Ubuntu Cheonjiin Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="297.11377" cy="639.69056" id="svg_80" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="270.44707" y="643.69056" id="svg_81" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="255.0152" y="653.69056" id="svg_82" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="     <?php
					  
												  //swon.wonchan.net
												  $host6 = '192.168.219.104';
												  if ($socket6 = @fsockopen($host6, 80)) {
													echo '#06c712';
													fclose($socket6);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="297.11377" cy="639.69056" id="svg_83" rx="50" ry="50" />
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="270.44707" y="643.81588" id="svg_84" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-102</text>
							  <text fill="#000000" stroke="#000" x="260.24922" y="653.76387" id="svg_85" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Ubuntu Swon Server</text>
							  <ellipse ry="2" rx="2" id="svg_87" cy="585.78825" cx="298.40414" stroke="#fff" fill="none" />
							  <text fill="#000000" stroke="#000" x="383.32101" y="643.80456" id="svg_88" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="367.88914" y="653.80456" id="svg_89" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="383.32101" y="643.92988" id="svg_90" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-101</text>
							  <text fill="#000000" stroke="#000" x="366.88914" y="653.80456" id="svg_91" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Ubuntu Cheonjiin Server</text>
							  <line stroke="#fff" fill="none" x1="408.40508" y1="564.31989" x2="408.48987" y2="584.33834" id="svg_92" />
							  <ellipse ry="2" rx="2" id="svg_93" cy="586.33834" cx="408.7038" stroke="#fff" fill="none" />
							  <text fill="#000000" stroke="#000" x="383.32101" y="643.80456" id="svg_94" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="367.88914" y="653.80456" id="svg_95" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="     <?php
					  
												  //static.wonchan.net
												  $host7 = '192.168.219.105';
												  if ($socket7 = @fsockopen($host7, 80)) {
													echo '#06c712';
													fclose($socket7);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="409.98771" cy="641.28956" id="svg_96" rx="50" ry="50" />
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="383.32101" y="643.92988" id="svg_97" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-103</text>
							  <text fill="#000000" stroke="#000" x="378.5274" y="654.23009" id="svg_98" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Static Web Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="518.38945" cy="639.26503" id="svg_99" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="491.72275" y="643.26503" id="svg_100" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="476.29089" y="653.26503" id="svg_101" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="518.38945" cy="639.26503" id="svg_102" rx="50" ry="50" />
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="491.72275" y="643.39035" id="svg_103" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-101</text>
							  <text fill="#000000" stroke="#000" x="476.29089" y="653.26503" id="svg_104" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Ubuntu Cheonjiin Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="518.38945" cy="639.26503" id="svg_105" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="491.72275" y="643.26503" id="svg_106" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="476.29089" y="653.26503" id="svg_107" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="     <?php
					  
												  //관리 서버
												  $host8 = '192.168.219.101';
												  if ($socket8 = @fsockopen($host8, 8006)) {
													echo '#06c712';
													fclose($socket8);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="518.38945" cy="639.26503" id="svg_108" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="491.29722" y="643.39035" id="svg_109" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-104</text>
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="487.86399" y="652.76392" id="svg_110" stroke-width="0" font-size="9" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Manage Server</text>
							  <path stroke="#fff" id="svg_111" d="m519.3811,569.44185l0.08479,14.16479" opacity="undefined" fill="none" />
							  <ellipse ry="2" rx="2" id="svg_112" cy="585.36272" cx="519.67982" stroke="#fff" fill="none" />
							  <line stroke="#fff" fill="none" x1="187.1294" y1="564.74542" x2="187.21419" y2="584.76387" id="svg_113" />
							  <line stroke="#fff" fill="none" x1="298.50661" y1="570.73345" x2="298.5914" y2="584.46447" id="svg_114" />
							  <path stroke="#fff" id="svg_115" d="m299.26872,570.97056l-170.1473,-44.20667" opacity="undefined" fill="none" />
							  <path stroke="#fff" id="svg_116" d="m408.25071,564.68314l-268.65025,-45.70368" opacity="undefined" fill="none" />
							  <path stroke="#fff" id="svg_117" d="m519.02912,569.47355l-374.63824,-66.06296" opacity="undefined" fill="none" />
							  <path stroke="#fff" id="svg_118" d="m719.5293,568.41848l-569.78938,-75.52709" opacity="undefined" fill="none" />
							  <ellipse fill="#fff" stroke="#000" cx="719.58699" cy="638.66623" id="svg_119" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="692.92029" y="642.66623" id="svg_120" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="677.48842" y="652.66623" id="svg_121" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="719.58699" cy="638.66623" id="svg_122" rx="50" ry="50" />
							  <text style="cursor: move;" fill="#000000" stroke="#000" x="692.92029" y="642.79155" id="svg_123" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-101</text>
							  <text fill="#000000" stroke="#000" x="677.48842" y="652.66623" id="svg_124" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Ubuntu Cheonjiin Server</text>
							  <ellipse fill="#fff" stroke="#000" cx="719.58699" cy="638.66623" id="svg_125" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="692.92029" y="642.66623" id="svg_126" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">vm-100</text>
							  <text fill="#000000" stroke="#000" x="677.48842" y="652.66623" id="svg_127" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Nginx SSL Proxy Server</text>
							  <ellipse fill="     <?php
					  
												  //라즈베리
												  $host9 = '192.168.219.101';
												  if ($socket9 = @fsockopen($host9, 80)) {
													echo '#06c712';
													fclose($socket9);
												  } else {
													echo '#730a10';
												  }
					  
												  ?>" stroke="#000" cx="719.58699" cy="638.66623" id="svg_128" rx="50" ry="50" />
							  <text fill="#000000" stroke="#000" x="709.42766" y="643.76392" id="svg_129" stroke-width="0" font-size="16" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">RPI</text>
							  <text fill="#000000" stroke="#000" x="673.50561" y="653.76392" id="svg_130" stroke-width="0" font-size="8" font-family="'Red Hat Display'" text-anchor="start" xml:space="preserve">Server Cam Video Server</text>
							  <path stroke="#fff" id="svg_131" d="m719.7005,568.80287l0.08479,14.16479" opacity="undefined" fill="none" />
							  <ellipse ry="2" rx="2" id="svg_132" cy="584.72375" cx="719.99922" stroke="#fff" fill="none" />
							  <text xml:space="preserve" text-anchor="start" font-family="'Red Hat Display'" font-size="13" id="svg_144" y="124.17767" x="435.79818" stroke="#ffffff" fill="#ffffff">Main Server CPU Usage: <?php //메인서버 온도
					  
																																																							//메인서버 CPU 사용량
																																																							$content2 = file_get_contents('http://192.168.219.101/api/usage.php');
					  
																																																							if ($content2 !== false) {
																																																							  // content 사용
																																																							  echo $content2 . "%";
																																																							} else {
																																																							  echo "CPU 사용량를 불러오는데 실패 했어요..";
																																																							} ?></text>
							  <text xml:space="preserve" text-anchor="start" font-family="'Red Hat Display'" font-size="13" id="svg_145" y="145.91683" x="436" stroke="#ffffff" fill="#ffffff">Main Server CPU temperature: <?php //메인서버 온도
					  
																																																							//메인서버 온도
																																																							$content3 = file_get_contents('http://192.168.219.101/api/temp.php');
					  
																																																							if ($content3 !== false) {
																																																							  // content 사용
																																																							  echo $content3;
																																																							} else {
																																																							  echo "CPU 온도를 불러오는데 실패 했어요..";
																																																							} ?></text>
							  <text xml:space="preserve" text-anchor="start" font-family="'Red Hat Display'" font-size="13" id="svg_145" y="166.91683" x="436" stroke="#ffffff" fill="#ffffff"><a href="https://usage.wonchan.net" style="text-decoration: underline;">Main 서버 사용량 (Dash Dot.)</a></text>
							</g>
					  
						  </svg>
                </form>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <ul class="outer-nav">
      <li class="is-active">Home</li>
      <li>Skills</li>
      <li>About</li>
      <li>Contact</li>
      <li>Server Status</li>
    </ul>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-2.2.4.min.js"><\/script>')</script>
  <script>
    //글시 출력 애니메이션 
    const content = "DevOps Enginner.";
    const text = document.querySelector(".dev-ops");
    let i = 0;

    function typing() {
      if (i < content.length) {
        let txt = content.charAt(i);
        text.innerHTML += txt;
        i++;
      }
    }
    setInterval(typing, 150)
  </script>
  <script src="assets/js/functions-min.js"></script>
</body>

</html>